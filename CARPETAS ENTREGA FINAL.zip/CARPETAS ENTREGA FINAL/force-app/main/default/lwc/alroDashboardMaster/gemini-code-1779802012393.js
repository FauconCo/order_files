import { LightningElement, track } from 'lwc';
import { subscribe, onError } from 'lightning/empApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class AlroDashboardMaster extends LightningElement {
    @track currentView = 'Ventas'; // Estado de la vista: Ventas | Soporte | Combinado
    @track salesData = {};
    @track supportData = {};
    @track overallConfidence = 1.0;
    
    channelName = '/event/Dashboard_Update__e';
    subscription = {};

    connectedCallback() {
        this.initEmpApi();
    }

    initEmpApi() {
        // Captura de errores globales en el bus de eventos
        onError((error) => {
            console.error('Error crítico en el bus de eventos de ALRO: ', JSON.stringify(error));
        });

        // Suscripción al WebSocket de Salesforce
        subscribe(this.channelName, -1, (response) => {
            this.processAgenticPayload(response.data.payload);
        }).then((sub) => {
            this.subscription = sub;
        });
    }

    processAgenticPayload(payload) {
        try {
            // Validar inmutabilidad y existencia de la carga útil
            if (!payload || !payload.DataJSON__c) {
                throw new Error('Payload agéntico nulo o incompleto.');
            }

            const parsedData = JSON.parse(payload.DataJSON__c);
            this.currentView = payload.Type__c; // Actualiza la vista dinámicamente (Ventas/Soporte/Combinado)
            this.overallConfidence = payload.Confidence__c || 1.0;

            // Enrutamiento reactivo de datos a los submódulos correspondientes
            if (payload.Type__c === 'Ventas') {
                this.salesData = parsedData;
            } else if (payload.Type__c === 'Soporte') {
                this.supportData = parsedData;
            } else if (payload.Type__c === 'Combinado') {
                this.salesData = parsedData.sales || {};
                this.supportData = parsedData.support || {};
            }
        } catch (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Capa de Confianza: Fallo de Inferencia',
                    message: 'La IA envió datos incompatibles. Aplicando fallback de visualización.',
                    variant: 'error'
                })
            );
        }
    }
}