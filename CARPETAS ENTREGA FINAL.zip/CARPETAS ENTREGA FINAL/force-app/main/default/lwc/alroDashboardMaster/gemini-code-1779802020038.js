// Fragmento conceptual para el FrontEnd LWC (No requiere Apex)
import { subscribe, unsubscribe, onError } from 'lightning/empApi';

// En el connectedCallback del LWC:
subscribe('/event/Dashboard_Update__e', -1, (response) => {
    // Si la IA ejecutó Ventas, renderizamos el gráfico de Oportunidades
    if(response.data.payload.Type__c === 'Ventas') {
        this.refreshSalesCharts(response.data.payload.DataJSON__c);
    }
});