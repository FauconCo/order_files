// Actualización del LWC para soportar mutación de plantillas
const envelope = JSON.parse(payload.DataJSON__c);
const template = envelope.metadata.templateType;

// Switch de renderizado seguro
switch(template) {
    case 'flex':
        this.renderFlexTemplate(envelope.payload);
        break;
    case 'multicast':
        this.renderMulticastTemplate(envelope.payload);
        break;
    default:
        // Evita el crash mostrando la data segura
        this.renderFallback(envelope.payload.fallbackText);
}