// Este código se ejecuta cuando el agente termina el renderizado
async function logTrazabilidad(action, status, details) {
  const eventData = {
    Action__c: action,
    Status__c: status,
    Details__c: details,
    Timestamp__c: new Date().toISOString()
  };

  // Usamos Salesforce CLI/JS Force para insertar
  await conn.sobject("Audit_Event__c").create(eventData, (err, res) => {
    if (err) return console.error("Error en trazabilidad:", err);
    console.log("Evento registrado en Salesforce ID:", res.id);
  });
}