// URL generada por tu script de Python en VS Code (Cópiala y pégala aquí)
const ALRO_API_URL = "https://tu-url-de-ngrok.app/api/v1/evaluate";

async function evaluarClienteSalesforce(clientId, score, volatilidad, historial) {
    const payload = {
        client_id: clientId,
        credit_score: score,
        market_volatility: volatilidad,
        history_vector: historial
    };

    try {
        // Petición al motor PyTorch en tu PC a través de Ngrok
        const respuesta = await fetch(ALRO_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const datos = await respuesta.json();
        
        // Renderizado en la interfaz (Neoglassmorphism Dashboard)
        document.getElementById('status-panel').innerText = `Acción: ${datos.accion_agente}`;
        document.getElementById('risk-metric').innerText = `Riesgo p90: ${(datos.riesgo_p90 * 100).toFixed(1)}%`;
        document.getElementById('latency-metric').innerText = `Latencia: ${datos.latencia_ms} ms`;
        
        if(datos.accion_agente === "REESTRUCTURAR_MORA") {
             document.getElementById('status-panel').classList.add('alert-red');
        }

    } catch (error) {
        console.error("Fallo de conexión E2E: ", error);
    }
}

// Simulación de un gatillo desde el botón "Auditar" en la UI
document.getElementById('btn-evaluar').addEventListener('click', () => {
    evaluarClienteSalesforce("CX-9981", 620, 0.85, [0.1, 0.4, 0.9, 0.8, 0.9]);
});