import { LightningElement, track } from 'lwc';
import processAgentLogic from '@salesforce/apex/AgentController.processAgentLogic';

export default class AlroDashboard extends LightningElement {
    @track loadingState = false;
    @track loadingStateLabel = '';

    async triggerAgent() {
        this.loadingState = true;
        
        // Fase 1: Anclando
        this.loadingStateLabel = 'Anclando Datos en Data Cloud...';
        
        // Fase 2: Validando
        this.loadingStateLabel = 'Validando Lógica vs Knowledge...';
        
        // Llamada al backend nativo (Apex)
        const result = await processAgentLogic({ prompt: 'generar_kpi_ventas' });
        
        // Fase 3: Renderizando
        this.loadingStateLabel = 'Renderizando Dashboard...';
        this.loadingState = false;
    }
}