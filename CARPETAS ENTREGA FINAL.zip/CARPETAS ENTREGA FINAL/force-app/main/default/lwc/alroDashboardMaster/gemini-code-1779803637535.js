// Dentro de tu componente Next.js
const [loadingState, setLoadingState] = useState(null); // 'anchoring', 'validating', 'rendering'

const triggerAgent = async (prompt) => {
  setLoadingState('anchoring');
  // Lógica: Consultar Data Cloud para el contexto
  
  setLoadingState('validating');
  // Lógica: Tree of Thoughts (ToT) vs Knowledge Articles
  
  setLoadingState('rendering');
  // Lógica: Cargar visualización y limpiar Workslop
  
  setLoadingState(null); // Finalizado
};