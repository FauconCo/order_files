import { LightningElement, track } from 'lwc';
import processAgentLogic from '@salesforce/apex/AgentController.processAgentLogic';

export default class AlroDashboard extends LightningElement {
    @track loadingState = false;
    @track loadingStateLabel = '';
    @track resultData = null;
    promptValue = 'Muéstrame la facturación del Q3';

    handleInputChange(event) {
        this.promptValue = event.target.value;
    }

    async triggerAgent() {
        this.loadingState = true;
        this.resultData = null;
        
        // El Teatro de Carga
        this.loadingStateLabel = 'Anclando Datos en Data Cloud...';
        await new Promise(resolve => setTimeout(resolve, 800)); // Simula latencia
        
        this.loadingStateLabel = 'Validando Lógica vs Knowledge...';
        await new Promise(resolve => setTimeout(resolve, 800)); 

        try {
            // Llamada al Apex Controller
            const result = await processAgentLogic({ prompt: this.promptValue });
            this.resultData = JSON.parse(result);
            this.loadingStateLabel = 'Renderizando Dashboard...';
        } catch (error) {
            console.error('Error del Agente:', error);
        } finally {
            this.loadingState = false;
        }
    }
}