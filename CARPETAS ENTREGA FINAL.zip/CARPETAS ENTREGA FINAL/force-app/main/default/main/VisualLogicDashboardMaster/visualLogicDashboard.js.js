import { LightningElement, track } from 'lwc';
import processRequest from '@salesforce/apex/ALRO_AgentOrchestrator.processRequest';

export default class VisualLogicDashboard extends LightningElement {
    @track userPrompt = '';
    @track isLoading = false;
    
    // Envelope State Properties
    @track isDelegated = false;
    @track isError = false;
    @track hasData = false;
    
    @track systemMessage = '';
    @track rawDashboardData = null;

    handlePromptChange(event) {
        this.userPrompt = event.target.value;
    }

    get formattedData() {
        return this.rawDashboardData ? JSON.stringify(this.rawDashboardData, null, 4) : '';
    }

    async executeAgent() {
        if (!this.userPrompt) return;

        this.isLoading = true;
        this.resetState();

        try {
            // Call Layer 1-3 Backend
            const backendResponse = await processRequest({ userInput: this.userPrompt });
            
            // ENVELOPE PATTERN: Strict JSON Parsing
            const envelope = JSON.parse(backendResponse);

            if (envelope.status === 'DELEGATED') {
                this.isDelegated = true;
                this.systemMessage = envelope.message || 'Delegado a analista humano por seguridad.';
            } 
            else if (envelope.status === 'SUCCESS') {
                this.hasData = true;
                this.systemMessage = 'Datos sincronizados exitosamente.';
                this.rawDashboardData = envelope.data;
            } 
            else {
                this.isError = true;
                this.systemMessage = envelope.message || 'Error desconocido del sistema.';
            }

        } catch (error) {
            // Graceful Crash Prevention
            this.isError = true;
            this.systemMessage = 'Fallo Crítico de Comunicación: ' + (error.body?.message || error.message || 'El JSON devuelto está corrupto.');
            console.error('ALRO System Exception:', error);
        } finally {
            this.isLoading = false;
        }
    }

    resetState() {
        this.isDelegated = false;
        this.isError = false;
        this.hasData = false;
        this.systemMessage = '';
        this.rawDashboardData = null;
    }
}