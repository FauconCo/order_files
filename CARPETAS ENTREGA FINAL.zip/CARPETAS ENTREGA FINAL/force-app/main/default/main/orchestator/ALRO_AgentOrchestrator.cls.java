public with sharing class ALRO_AgentOrchestrator {
    
    // Threshold defined by the Architectural Master Prompt
    private static final Decimal CONFIDENCE_THRESHOLD = 0.85;

    @AuraEnabled
    public static String processRequest(String userInput) {
        Long startTime = System.currentTimeMillis();
        String actionType = 'SUCCESS';
        String jsonPayload = '';
        Decimal confidenceScore = 0.0;
        
        try {
            // 1. Math & Security Layer: Simulate Quantile Loss (p90) and Tanh Validation
            confidenceScore = calculateMathematicalConfidence(userInput);
            
            // 2. Threshold Governance (Hallucination Block)
            if (confidenceScore < CONFIDENCE_THRESHOLD) {
                actionType = 'HALLUCINATION_BLOCKED';
                jsonPayload = generateEnvelope('DELEGATED', 'Fallo Cuantílico detectado. Riesgo de alucinación supera p90. Delegando a humano.', null);
                publishAuditLedger(actionType, confidenceScore, (System.currentTimeMillis() - startTime), userInput);
                return jsonPayload;
            }

            // 3. Execution Layer: Call Einstein Prompt Template (Agentforce)
            // Template Name must match your actual Flex template DeveloperName
            String templateName = 'ALRO_Orchestrator'; 
            
            ConnectApi.EinsteinPromptTemplateInput promptInput = new ConnectApi.EinsteinPromptTemplateInput();
            promptInput.inputParams = new Map<String, ConnectApi.WrappedValue>();
            
            ConnectApi.WrappedValue textInput = new ConnectApi.WrappedValue();
            textInput.value = userInput;
            promptInput.inputParams.put('Prompt_Usuario', textInput);

            // Execute the LLM Call safely behind Einstein Trust Layer
            ConnectApi.EinsteinPromptTemplateGenerations response = ConnectApi.EinsteinLLM.generateMessagesForPromptTemplate(templateName, promptInput);
            String rawLlmResponse = response.generations[0].text;
            
            // Assuming the LLM returns pure JSON based on our prompt grounding
            jsonPayload = generateEnvelope('SUCCESS', 'Dashboard generado exitosamente.', rawLlmResponse);

        } catch (Exception ex) {
            actionType = 'SYSTEM_ERROR';
            jsonPayload = generateEnvelope('ERROR', 'System Exception: ' + ex.getMessage(), null);
        } finally {
            // 4. Audit Layer: Immutable Telemetry
            Long latency = System.currentTimeMillis() - startTime;
            publishAuditLedger(actionType, confidenceScore, latency, jsonPayload);
        }
        
        return jsonPayload;
    }

    /**
     * Simulates the Quantile Loss p90 and Hyperbolic Tangent (Tanh) normalizer.
     * In a production Agent, this is trained data; here we simulate the Guardrail.
     */
    private static Decimal calculateMathematicalConfidence(String input) {
        if (String.isBlank(input)) return -1.0;
        String lowerInput = input.toLowerCase();
        
        // Simulating the p90 loss for out-of-domain contexts (Workslop/Hallucination risk)
        if (lowerInput.contains('clima') || lowerInput.contains('weather') || lowerInput.contains('chiste') || lowerInput.contains('poema')) {
            // Math.tanh(0.5) ≈ 0.4621 (Below 0.85 threshold)
            return Math.tanh(0.5); 
        }
        
        // Simulating high confidence for Sales/Support topics
        // Math.tanh(1.5) ≈ 0.9051 (Passes 0.85 threshold)
        return Math.tanh(1.5); 
    }

    private static String generateEnvelope(String status, String message, String dataString) {
        // Enforces the "Envelope Pattern" for the LWC
        Map<String, Object> envelope = new Map<String, Object>{
            'status' => status,
            'message' => message,
            'data' => dataString != null ? JSON.deserializeUntyped(dataString) : null
        };
        return JSON.serialize(envelope);
    }

    private static void publishAuditLedger(String actionType, Decimal confidence, Long latency, String payload) {
        Audit_Ledger__e ledgerEvent = new Audit_Ledger__e(
            Action_Type__c = actionType,
            Confidence_Score__c = confidence,
            Latency_ms__c = latency,
            Payload__c = payload.abbreviate(131000)
        );
        EventBus.publish(ledgerEvent);
    }
}